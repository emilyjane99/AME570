# Assignment 5
`Due April 3rd, before class`

## Task
Deploy the attached simple login example (in `code` folder), over https using AWS EC2.

## Usage

1. Make a copy of the code handout.
2. Edit `https.js`.
3. `chmod +x portmap.sh`
4. `./portmap.sh`
5. In EC2 'Security Groups' open ports 80,8080,443,8443
5. `forever start https.js`


## Todo
Please update your server IP here:
https://docs.google.com/spreadsheets/d/1dRiGIJL4BJptlfHKopJgvC1eaajR15cNj0H6VOk-kdk/edit?usp=sharing
