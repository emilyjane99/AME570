# Simple authentication using Node.js + Passport.js

## Usage

0. Make sure mongoDB is running at `mongodb:127.0.0.1:27017`.
1. clone repo: `git clone https://github.com/tejaswigowda/simpleAuth.git`.
2. `cd code`
3. `node server.js`
4. Goto http://localhost:8080
