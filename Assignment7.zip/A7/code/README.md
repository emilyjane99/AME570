## S3 bucket to use:

https://bucket470570.s3.us-west-2.amazonaws.com

## Tokens 

See Canvas


## S3 bucket CORS config

```
[
    {
        "AllowedHeaders": [
            "*"
        ],
        "AllowedMethods": [
            "HEAD",
            "GET",
            "PUT",
            "POST",
            "DELETE"
        ],
        "AllowedOrigins": [
            "*"
        ],
        "ExposeHeaders": [
            "ETag"
        ]
    }
]
```
