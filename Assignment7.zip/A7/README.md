# Assignment 7
`Due April 24th, before midnight`

## Task
Please implement changing the image title to the imageApp developed in class. Start with the code handout given.

## Reference

https://github.com/tejaswigowda/ame470570Spring2023/tree/main/imageApp
